k = int(input())
for _ in range(k):
    n = int(input())
    print(n-1)
